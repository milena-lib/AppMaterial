export enum GridColumnTypeEnum {
    text,
    number,
    date,
    dateTime,
    link,
    icon
}
